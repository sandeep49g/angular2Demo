import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  accounts;
  pieChartData:(number | string | object)[][];
  pieChartOptions;
  ngOnInit() {
    this.accounts = [
      {name: 'Brokerage Account3', marketValue: 1999990.00, cash: 1995826.00, legend:this.getRandomColor()},
      {name: 'Account3', marketValue: 1948954.00, cash: 1936954.00, legend:this.getRandomColor()},
      {name: '', marketValue: 3948944.00, cash: 3932780.00, legend: ''}
    ];
    this.pieChartData = [[
      {label: 'Name', role: 'domain'}, 
      {label: 'Cash %', role: 'data'}
    ]];
    this.accounts.forEach((account, index) => {
      let lastElement = this.accounts[this.accounts.length-1];
      if(index < this.accounts.length-1) {
        this.pieChartData.push([
          account.name,
          (account.cash / lastElement.cash * 100)
        ]);
      }
    });
    this.pieChartOptions = {
      chartType: 'PieChart',
      dataTable : this.pieChartData,
      options: {
        slices: this.accounts
                  .reduce((acc, curr, i) => { console.log(i); acc[i] = {color: curr.legend}; return acc}, {0: {color: this.accounts[0].legend}})
      }
    };
  }
  
  addAccount() {
    let marketValue:any = (Math.random() * 10000).toFixed(2);
    this.accounts.splice(this.accounts.length-1, 0, {name: 'Random Account', marketValue: marketValue, cash: (marketValue - 200), legend:this.getRandomColor()});
  }
  
  generateRandomColor() {
    let letters:string = '0123456789ABCDEF';
    let color:string = '#';
    for (var i = 0; i < 6; i++ ) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
  getRandomColor() {
    let colors:Array<string> = [];
    let color:string = this.generateRandomColor();
    while(colors.includes(color)) {
      color = this.generateRandomColor();
    }
    return color;
  }
}
